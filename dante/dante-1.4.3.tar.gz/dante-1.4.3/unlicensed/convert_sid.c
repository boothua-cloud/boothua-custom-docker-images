#include <errno.h>
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

int
main(int argc, char *argv[])
{
   
   return 1;
}
