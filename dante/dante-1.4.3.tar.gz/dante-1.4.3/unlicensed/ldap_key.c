/*
 * $Id: ldap_key.c,v 1.6 2013/08/19 06:55:55 michaels Exp $
 *
 * Copyright (c) 2009, 2011
 *      Inferno Nettverk A/S, Norway.  All rights reserved.
 */

#include "common.h"

static const char rcsid[] =
"$Id: ldap_key.c,v 1.6 2013/08/19 06:55:55 michaels Exp $";

const licensekey_t *module_ldap_keyv = NULL;
const size_t       module_ldap_keyc  = 0;
