uint16_t in_cksum(uint16_t *addr, int len);
